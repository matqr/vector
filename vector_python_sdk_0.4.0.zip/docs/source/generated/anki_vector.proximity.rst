anki\_vector.proximity
======================

.. automodule:: anki_vector.proximity

   
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
   
      ProximityComponent
      ProximitySensorData
   
   

   
   
   